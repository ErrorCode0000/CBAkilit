import os
import sys
import subprocess

# pywin32 kütüphanesini içe aktarmaya çalış. Yoksa kullanıcıyı bilgilendir.
try:
    import winshell
    # winshell kütüphanesi win32com.client'ı da kullanır, bu yüzden onu da kontrol etmek iyi bir pratik olabilir.
    import win32com.client 
except ImportError:
    winshell = None
    print("Hata: 'pywin32' kütüphanesi bulunamadı.")
    print("Bu kurulum aracını kullanmak için lütfen 'pip install pywin32' komutunu çalıştırın.")
    sys.exit(1) # Kütüphane yoksa betiği sonlandır.

def create_and_place_shortcut(target_file_path, shortcut_name="CBA-Kilit Akıllı Tahta"):
    """
    Belirtilen Python dosyasının masaüstüne kısayolunu oluşturur
    ve Windows başlangıç klasörüne ekler.
    
    Args:
        target_file_path (str): Kısayolu oluşturulacak ana uygulamanın tam yolu (örneğin kilit_uygulamasi.py).
        shortcut_name (str): Oluşturulacak kısayolun adı.
    """
    if not sys.platform.startswith('win'):
        print(f"Bu işlem sadece Windows işletim sistemlerinde desteklenmektedir. Mevcut OS: {sys.platform}")
        return

    if winshell is None:
        print("Kısayol oluşturma için 'pywin32' kütüphanesi gerekli ancak bulunamadı.")
        return

    if not os.path.exists(target_file_path):
        print(f"Hata: Hedef dosya bulunamadı: {target_file_path}")
        print("Lütfen hedef dosyanın doğru yolda olduğundan emin olun.")
        return

    # Python çalıştırıcısının yolu (bu betiği çalıştıran Python yorumlayıcısı)
    python_executable = sys.executable
    
    # Kısayolun çalışma dizini (genellikle hedef dosyanın olduğu klasör)
    working_directory = os.path.dirname(target_file_path)

    print(f"'{target_file_path}' için kısayollar oluşturuluyor...")

    # Masaüstü kısayolu oluşturma
    try:
        desktop_path = winshell.desktop()
        desktop_shortcut_path = os.path.join(desktop_path, f"{shortcut_name}.lnk")

        with winshell.shortcut(desktop_shortcut_path) as link:
            link.path = python_executable
            link.arguments = f'"{target_file_path}"' # Hedef Python dosyasını argüman olarak veriyoruz
            link.description = f"{shortcut_name} Uygulaması"
            link.working_directory = working_directory
            # İsteğe bağlı: Kısayola ikon ekleyebilirsiniz (örneğin aynı klasördeki bir .ico dosyası)
            # link.icon_location = (os.path.join(working_directory, 'app_icon.ico'), 0) 
        print(f"Masaüstüne '{shortcut_name}.lnk' kısayolu başarıyla oluşturuldu.")
    except Exception as e:
        print(f"Masaüstü kısayolu oluşturulurken hata oluştu: {e}")

    # Başlangıç klasörü kısayolu oluşturma
    try:
        startup_path = winshell.startup()
        startup_shortcut_path = os.path.join(startup_path, f"{shortcut_name}.lnk")

        with winshell.shortcut(startup_shortcut_path) as link:
            link.path = python_executable
            link.arguments = f'"{target_file_path}"'
            link.description = f"{shortcut_name} Başlangıç Öğesi"
            link.working_directory = working_directory
            # link.icon_location = (os.path.join(working_directory, 'app_icon.ico'), 0)
        print(f"Başlangıç klasörüne '{shortcut_name}.lnk' kısayolu başarıyla eklendi.")
    except Exception as e:
        print(f"Başlangıç klasörüne kısayol eklenirken hata oluştu: {e}")

if __name__ == "__main__":
    # --- Kurulum Yapılacak Hedef Dosya ---
    # Bu, asıl kilit ekranı uygulamanızın dosya yolu olmalıdır.
    # Bu 'kurulum_araci.py' ile aynı dizinde olduğunu varsayalım.
    
    # Mevcut betiğin (kurulum_araci.py) bulunduğu dizin
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Hedef uygulamanızın adı (örneğin kilit_uygulamasi.py)
    target_app_filename = "CBAkilit.py" # BURAYI KENDİ KİLİT UYGULAMANIZIN ADI İLE DEĞİŞTİRİN
    
    # Hedef uygulamanızın tam yolu
    target_app_path = os.path.join(current_dir, target_app_filename)

    print(f"Kurulacak hedef uygulama: {target_app_path}")
    
    # Kısayolları oluştur ve yerleştir
    create_and_place_shortcut(target_app_path, "CBA-Kilit")
    
    print("\nKurulum işlemi tamamlandı.")
    print(f"Masaüstünüzü ve Başlangıç klasörünüzü kontrol ediniz.")
    print(f"Hedef dosya '{target_app_filename}' bulunamazsa, kısayollar çalışmayacaktır.")
    
    # İsteğe bağlı: Kullanıcının enter tuşuna basmasını bekle
    # input("\nÇıkmak için Enter tuşuna basın...")