import os
import sys
import winshell

def remove_shortcuts(shortcut_name="CBA-Kilit"):
    """
    Belirtilen addaki kısayolları masaüstünden ve Windows başlangıç klasöründen siler.
    
    Args:
        shortcut_name (str): Silinecek kısayolun adı (uzantısız).
    """
    if not sys.platform.startswith('win'):
        print(f"Bu işlem sadece Windows işletim sistemlerinde desteklenmektedir. Mevcut OS: {sys.platform}")
        return

    if winshell is None:
        print("Kısayol silme için 'pywin32' kütüphanesi gerekli ancak bulunamadı.")
        return

    print(f"'{shortcut_name}' kısayolları kaldırılıyor...")

    # Masaüstü kısayolunu kaldırma
    try:
        desktop_path = winshell.desktop()
        desktop_shortcut_path = os.path.join(desktop_path, f"{shortcut_name}.lnk")
        
        if os.path.exists(desktop_shortcut_path):
            os.remove(desktop_shortcut_path)
            print(f"Masaüstünden '{shortcut_name}.lnk' kısayolu başarıyla kaldırıldı.")
        else:
            print(f"Masaüstünde '{shortcut_name}.lnk' kısayolu bulunamadı.")
    except Exception as e:
        print(f"Masaüstü kısayolu kaldırılırken hata oluştu: {e}")

    # Başlangıç klasörü kısayolunu kaldırma
    try:
        startup_path = winshell.startup()
        startup_shortcut_path = os.path.join(startup_path, f"{shortcut_name}.lnk")

        if os.path.exists(startup_shortcut_path):
            os.remove(startup_shortcut_path)
            print(f"Başlangıç klasöründen '{shortcut_name}.lnk' kısayolu başarıyla kaldırıldı.")
        else:
            print(f"Başlangıç klasöründe '{shortcut_name}.lnk' kısayolu bulunamadı.")
    except Exception as e:
        print(f"Başlangıç klasörü kısayolu kaldırılırken hata oluştu: {e}")

if __name__ == "__main__":
    # Kaldırılacak kısayolun adı (install.py'de kullanılanla aynı olmalı)
    shortcut_to_remove = "CBA-Kilit" 
    
    # Kısayolları kaldır
    remove_shortcuts(shortcut_to_remove)
    
    print("\nKaldırma işlemi tamamlandı.")
    # input("\nÇıkmak için Enter tuşuna basın...")